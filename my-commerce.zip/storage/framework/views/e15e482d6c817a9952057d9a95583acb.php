<meta name="description" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/')); ?>website/assets/images/favicon.svg" />

<link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/LineIcons.3.0.css" />
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/tiny-slider.css" />
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/glightbox.min.css" />
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/main.css" />
<?php /**PATH C:\xampp\htdocs\my-commerce\resources\views/website/includes/style.blade.php ENDPATH**/ ?>